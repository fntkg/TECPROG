public class Fichero extends Enlace{

    public Fichero(String name, Integer size) {
        super(name, size);
    }
}
