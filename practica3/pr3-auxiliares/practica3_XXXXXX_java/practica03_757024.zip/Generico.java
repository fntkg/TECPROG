public interface Generico extends ProductoEspecial {
}
