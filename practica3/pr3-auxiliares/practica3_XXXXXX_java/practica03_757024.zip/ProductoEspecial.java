public interface ProductoEspecial {
    double volumen();
    double peso();
    String nombre();
    String productType();
}
